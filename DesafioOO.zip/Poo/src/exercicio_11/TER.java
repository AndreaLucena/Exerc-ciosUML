package exercicio_11;

import java.util.ArrayList;

public class TER extends ZonaEleitoral{
	
	private int numeroZona;
	
	public TER(String endereco, String cep, ArrayList<Eleitor> eleitor,
			int numeroZona) {
		super(endereco, cep, eleitor);
		this.numeroZona = numeroZona;
	}

	public int getNumeroZona() {
		return numeroZona;
	}

	public void setNumeroZona(int numeroZona) {
		this.numeroZona = numeroZona;
	}
	
	

}
