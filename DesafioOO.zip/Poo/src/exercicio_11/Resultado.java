package exercicio_11;

import java.util.ArrayList;

public class Resultado {
	
	private int candidatoID;
	private ArrayList<ServidorDosVotos> servidores = new ArrayList<ServidorDosVotos>();

	public Resultado(int candidatoID, ArrayList<ServidorDosVotos> servidores) {
		super();
		this.candidatoID = candidatoID;
		this.servidores = servidores;
	}
	public int getCandidatoID() {
		return candidatoID;
	}
	public void setCandidatoID(int candidatoID) {
		this.candidatoID = candidatoID;
	}


	public ArrayList<ServidorDosVotos> getServidores() {
		return servidores;
	}


	public void setServidores(ArrayList<ServidorDosVotos> servidores) {
		this.servidores = servidores;
	}


	public int getTotalVotos(){
		return 0;		
	}
	public void divulgarVencedor(){
	}

}
