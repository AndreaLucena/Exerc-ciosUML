package exercicio_11;

import java.util.ArrayList;

public class ZonaEleitoral {
	
	private String Endereco;
	private String cep;
	
	private ArrayList<Eleitor> eleitor = new ArrayList<Eleitor>();
	
	public ZonaEleitoral(String endereco, String cep, ArrayList<Eleitor> eleitor) {
		super();
		Endereco = endereco;
		this.cep = cep;
		this.eleitor = eleitor;
	}
	public String getEndereco() {
		return Endereco;
	}
	public void setEndereco(String endereco) {
		Endereco = endereco;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public ArrayList<Eleitor> getEleitor() {
		return eleitor;
	}
	public void setEleitor(ArrayList<Eleitor> eleitor) {
		this.eleitor = eleitor;
	}
}
