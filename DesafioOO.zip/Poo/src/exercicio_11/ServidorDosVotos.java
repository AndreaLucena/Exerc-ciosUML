package exercicio_11;

import java.util.ArrayList;
import java.util.Calendar;

public class ServidorDosVotos {
	
	private int candidatoID;
	private int eleitorID;
	private Calendar data;
	private int contaVotos;
	
	private ArrayList<Votar> votar = new ArrayList<Votar>();
	
	private ArrayList<Resultado> resultado = new ArrayList<Resultado>();
	
	public ServidorDosVotos(int candidatoID, int eleitorID, Calendar data,
			int contaVotos, ArrayList<Votar> votar,
			ArrayList<Resultado> resultado) {
		super();
		this.candidatoID = candidatoID;
		this.eleitorID = eleitorID;
		this.data = data;
		this.contaVotos = contaVotos;
		this.votar = votar;
		this.resultado = resultado;
	}

		public int getCandidatoID() {
		return candidatoID;
	}

	public void setCandidatoID(int candidatoID) {
		this.candidatoID = candidatoID;
	}

	public int getEleitorID() {
		return eleitorID;
	}



	public void setEleitorID(int eleitorID) {
		this.eleitorID = eleitorID;
	}



	public Calendar getData() {
		return data;
	}



	public void setData(Calendar data) {
		this.data = data;
	}



	public int getContaVotos() {
		return contaVotos;
	}



	public void setContaVotos(int contaVotos) {
		this.contaVotos = contaVotos;
	}



	public ArrayList<Resultado> getResultado() {
		return resultado;
	}



	public void setResultado(ArrayList<Resultado> resultado) {
		this.resultado = resultado;
	}



		public int contaVotos(){
		return contaVotos;
	}
	public ArrayList<Votar> getVotar() {
		return votar;
	}
	public void setVotar(ArrayList<Votar> votar) {
		this.votar = votar;
	}
	

}
