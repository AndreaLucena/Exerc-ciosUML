package exercicio_11;

import java.util.ArrayList;

public class Casa extends ZonaEleitoral{
	
	private int numeroCasa;

	public Casa(String endereco, String cep, ArrayList<Eleitor> eleitor,
			int numeroCasa) {
		super(endereco, cep, eleitor);
		this.numeroCasa = numeroCasa;
	}

	public int getNumeroCasa() {
		return numeroCasa;
	}

	public void setNumeroCasa(int numeroCasa) {
		this.numeroCasa = numeroCasa;
	}
}
