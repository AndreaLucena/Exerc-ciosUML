package exercicio_11;

import java.util.Calendar;

public class Votar {
	
	private int candidatoID;
	private int eleitorID;
	private Calendar data;
	private String cargoCandidato;
	
	private ServidorDosVotos servidorDeVotos;
	
	public Votar(int candidatoID, int eleitorID, Calendar data,
			String cargoCandidato, ServidorDosVotos servidorDeVotos) {
		super();
		this.candidatoID = candidatoID;
		this.eleitorID = eleitorID;
		this.data = data;
		this.cargoCandidato = cargoCandidato;
		this.servidorDeVotos = servidorDeVotos;
	}
	public int getCandidatoID() {
		return candidatoID;
	}
	public void setCandidatoID(int candidatoID) {
		this.candidatoID = candidatoID;
	}
	public int getEleitorID() {
		return eleitorID;
	}
	public void setEleitorID(int eleitorID) {
		this.eleitorID = eleitorID;
	}
	public Calendar getData() {
		return data;
	}
	public void setData(Calendar data) {
		this.data = data;
	}
	public String getCargoCandidato() {
		return cargoCandidato;
	}
	public void setCargoCandidato(String cargoCandidato) {
		this.cargoCandidato = cargoCandidato;
	}
	public ServidorDosVotos getServidorDeVotos() {
		return servidorDeVotos;
	}
	public void setServidorDeVotos(ServidorDosVotos servidorDeVotos) {
		this.servidorDeVotos = servidorDeVotos;
	}

	public void votar(){
	}
	public void cancelar(){
		
	}
}
	