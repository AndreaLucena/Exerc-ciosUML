package exercicio_12;

public interface Relogio {
	
	public void ajustarHora();
		
	public void ajustarAlarme();

}
