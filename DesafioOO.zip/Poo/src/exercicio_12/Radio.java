package exercicio_12;

public interface Radio{

	public void mudarEstacao();
		
	public void tocar();
		
	}
