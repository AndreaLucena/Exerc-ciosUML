package exercicio_12;

public class RelogioPulso extends RelogioImpl implements Relogio{
	
	private int tipoPulseira;

	public RelogioPulso(String marca, String tipo, int tipoPulseira) {
		super(marca, tipo);
		this.tipoPulseira = tipoPulseira;
	}

	public int getTipoPulseira() {
		return tipoPulseira;
	}

	public void setTipoPulseira(int tipoPulseira) {
		this.tipoPulseira = tipoPulseira;
	}

	@Override
	public String getMarca() {
		// TODO Auto-generated method stub
		return super.getMarca();
	}

	@Override
	public void setMarca(String marca) {
		// TODO Auto-generated method stub
		super.setMarca(marca);
	}

	@Override
	public String getTipo() {
		// TODO Auto-generated method stub
		return super.getTipo();
	}

	@Override
	public void setTipo(String tipo) {
		// TODO Auto-generated method stub
		super.setTipo(tipo);
	}

	@Override
	public void ajustarHora() {
		// TODO Auto-generated method stub
		super.ajustarHora();
	}

	@Override
	public void ajustarAlarme() {
		// TODO Auto-generated method stub
		super.ajustarAlarme();
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}
	
}