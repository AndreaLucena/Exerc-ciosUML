package exercio_10;

import java.util.ArrayList;

public class DaoClienteImpl implements DaoCliente{
	
	private ArrayList<Cliente> lista = new ArrayList<Cliente>();
	
	private ConexaoImpl conexaoImpl;

	public ArrayList<Cliente> getLista() {
		return lista;
	}

	public void setLista(ArrayList<Cliente> lista) {
		this.lista = lista;
	}

	public ConexaoImpl getConexaoImpl() {
		return conexaoImpl;
	}

	public void setConexaoImpl(ConexaoImpl conexaoImpl) {
		this.conexaoImpl = conexaoImpl;
	}

	@Override
	public Cliente incluir(Cliente cliente) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void excluir(Integer codigo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Cliente alterar(Cliente cliente) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Cliente> listar(ArrayList<Cliente> cliente) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cliente get(Cliente cliente) {
		// TODO Auto-generated method stub
		return null;
	}
}
