package exercio_10;

import java.sql.Connection;

public interface Conexao {
	
	public Connection conectar();
	
	public void desconectar(Connection com);

}
