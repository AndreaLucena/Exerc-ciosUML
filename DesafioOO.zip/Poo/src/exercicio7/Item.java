package exercicio7;

public class Item {
	
	public int codigo;
	public int nome;
	public int descrição;
	public Item(int codigo, int nome, int descrição) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.descrição = descrição;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public int getNome() {
		return nome;
	}
	public void setNome(int nome) {
		this.nome = nome;
	}
	public int getDescrição() {
		return descrição;
	}
	public void setDescrição(int descrição) {
		this.descrição = descrição;
	}
}
	
	
