package exercicio7;

import java.util.List;

public class Modelo {
	
	private int codigo;
	private String marca;
	private String nome;
	private Double motor;
	private int serie;
	private List<Item> itens;
	
	public Modelo(int codigo, String marca, String nome, Double motor,
			int serie, List<Item> itens) {
		super();
		this.codigo = codigo;
		this.marca = marca;
		this.nome = nome;
		this.motor = motor;
		this.serie = serie;
		this.itens = itens;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Double getMotor() {
		return motor;
	}
	public void setMotor(Double motor) {
		this.motor = motor;
	}
	public int getSerie() {
		return serie;
	}
	public void setSerie(int serie) {
		this.serie = serie;
	}
	public List<Item> getItens() {
		return itens;
	}
	public void setItens(List<Item> itens) {
		this.itens = itens;
	}
	
	

}
