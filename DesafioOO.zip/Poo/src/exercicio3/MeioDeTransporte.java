package exercicio3;

public abstract class MeioDeTransporte {
	
	private int id;
	private short ano;
	private String modelo;
	private double carga_maxima;
		
	public MeioDeTransporte(){
		
	}
		
	public MeioDeTransporte(int id, short ano, String modelo, double carga_maxima){
			
	}
	public int getId() {
		return this.id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public short getAno() {
		return this.ano;
	}
	public void setAno(short ano) {
		this.ano = ano;
	}
	public String getModelo() {
		return this.modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public double getCarga_maxima() {
		return this.carga_maxima;
	}
	public void setCarga_maxima(double carga_maxima) {
		this.carga_maxima = carga_maxima;
	}
	public abstract double Consumo();
}



