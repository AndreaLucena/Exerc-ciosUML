package exercicio3;

public class Terrestre extends MeioDeTransporte {
	
	int quantRodas;
	double potencia;
	
	public Terrestre (int id, short ano, String modelo, double carga_maxima, int quantRodas, double potencia){
		super(id, ano, modelo, carga_maxima);
		this.quantRodas = quantRodas;
		this.potencia = potencia;
		
	}

	public int getQuantRodas() {
		return this.quantRodas;
	}

	public void setQuantRodas(int quantRodas) {
		this.quantRodas = quantRodas;
	}

	public double getPotencia() {
		return this.potencia;
	}

	public void setPotencia(double potencia) {
		this.potencia = potencia;
	}
	@Override
	public double Consumo(){
		return (this.potencia * super.getCarga_maxima() * 100);
		
	}
}
