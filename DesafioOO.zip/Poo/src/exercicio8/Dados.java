package exercicio8;

import java.util.ArrayList;

public class Dados {
	
	private ArrayList<Transporte> lista = new ArrayList<Transporte>();

	public void adicionar(Transporte t) throws Exception{
		lista.add(t);
	}
		
	public void excluir(Transporte t){
		
	}
}
	
	
