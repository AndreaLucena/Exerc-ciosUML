package exercicio1;

public class Transporte {
	
	private int id;
	private int ano;
	private String modelo;
	private double carga_maxima;
	private double potencia;
	
	public Transporte(){
		id = 1;
		ano = 2009;
		modelo = "CBX 500";
		carga_maxima = 85.8;
		potencia = 45.8;
				
	}
	public Transporte (int id, int ano, String modelo, double carga_maxima, double potencia){
		this.id = id;
		this.ano = ano;
		this.modelo = modelo;
		this.carga_maxima = carga_maxima;
		this.potencia = potencia;
	}
	public int getId(){
		return this.id;
	}
	public void setId (int id){
		this.id = id;
	}
	public int getAno(){
		return this.ano;
	}
	public void setAno (int ano){
		this.ano = ano;
	}
	public String getModelo(){
		return this.modelo;
	}
	public void setModelo (String modelo){
		this.modelo = modelo;
	}
	public double getCarga_maxima(){
		return this.carga_maxima;
	}
	public void setCarga_maxima (double carga_maxima){
		this.carga_maxima = carga_maxima;
	}
	public double getPotencia(){
		return this.potencia;
	}
	public void setPotencia (double potencia){
		this.potencia = potencia;
	}	
	public double consumo(){
		return (this.potencia * this.carga_maxima * 100);
	}
	
}
