package exercicio6;

public class Dependente {
	
	int sequencial;
	String nomeCompleto;
	Integer sexo;
	String dataDeNascimento;
	boolean participaPlano;
	private Funcionario funcionario;
	
	
	public Dependente(int sequencial, String nomeCompleto, Integer sexo,
			String dataDeNascimento, boolean participaPlano,
			Funcionario funcionario) {
		super();
		this.sequencial = sequencial;
		this.nomeCompleto = nomeCompleto;
		this.sexo = sexo;
		this.dataDeNascimento = dataDeNascimento;
		this.participaPlano = participaPlano;
		this.funcionario = funcionario;
	}
	public int getSequencial() {
		return sequencial;
	}
	public void setSequencial(int sequencial) {
		this.sequencial = sequencial;
	}
	public String getNomeCompleto() {
		return nomeCompleto;
	}
	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}
	public Integer getSexo() {
		return sexo;
	}
	public void setSexo(Integer sexo) {
		this.sexo = sexo;
	}
	public String getDataDeNascimento() {
		return dataDeNascimento;
	}
	public void setDataDeNascimento(String dataDeNascimento) {
		this.dataDeNascimento = dataDeNascimento;
	}
	public boolean isParticipaPlano() {
		return participaPlano;
	}
	public void setParticipaPlano(boolean participaPlano) {
		this.participaPlano = participaPlano;
	}
	public Funcionario getFuncionario() {
		return funcionario;
	}
	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}
	
	

}
