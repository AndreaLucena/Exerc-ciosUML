package exercício4;

public class Ferramenta extends ItemDeLoja{
	
	private String categoria;
	private Integer serial;
	
	public Ferramenta(int codigoDoItem, String nomeDoItem, String descricaoDoItem, double valorDoItem, String categoria, Integer serial){
		super(codigoDoItem, nomeDoItem, descricaoDoItem, valorDoItem);
		this.categoria = categoria;
		this.serial = serial;
		}

	public String getCategoria() {
		return this.categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public Integer getSerial() {
		return this.serial;
	}

	public void setSerial(Integer serial) {
		this.serial = serial;
	}
	
	
	public int getIdentificador(){
		return serial;
	}
	public void separar(){
		this.setCategoria("Outros");
	}
	
	public static String separar(String valor){
		return valor;
	}
	
	
}
